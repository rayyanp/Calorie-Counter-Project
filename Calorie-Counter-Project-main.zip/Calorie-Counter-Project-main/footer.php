<?php
echo <<<FOOTER
        <footer>
            <script src="scripts/chooseInput.js"></script>
            <script src="scripts/toggleEdit.js"></script>
            <script src="scripts/toggleHome.js"></script>
        </footer>

    </html>
FOOTER;
?>